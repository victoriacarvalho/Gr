// imports
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;                 // Rectangle2D
import javax.media.opengl.*;
import javax.media.opengl.glu.*;
import javax.media.opengl.awt.*;        // GLCanvas
import javax.media.opengl.fixedfunc.*;
import com.jogamp.opengl.util.*;        // Animator
import com.jogamp.opengl.util.awt.*;    // TextRenderer
import java.lang.Math;


public class Pong implements GLEventListener, KeyListener
{

	private static final int SCREEN_WIDTH = 800;
	private static final int SCREEN_HEIGHT = 600;
	private static final int FPS = 120;              
	private static final double PADDLE_SPEED = 400;   
	private static final int MAX_SCORE = 5;         
	private static final double READY_TIME = 1.0;
	private static final int BALL_RADIUS = 5;        


	private static GLCanvas canvas;
	
	private static FPSAnimator animator;
	private static GLU glu;
	private static Frame frame;
	private static double AI_UPDATE_TIME = 1.5;
	private static double BALL_SPEED = 300;   

	
	private double gameTime;     
	private double frameTime;    
	private long prevTime;      
	private double aiTime;
	private double readyTime;

	private int screenWidth;
	private int screenHeight;

	private Ball ball;
	private Paddle player;
	private Paddle computer;

	private TextRenderer textRenderer;
	private SoundPlayer sound = new SoundPlayer(); 
	private int playerScore = 0;
	private int computerScore = 0;

	public enum GameState { MENU, START, READY, GAME }
	private GameState gameState = GameState.MENU;

	public static void main(String[] args)
	{
		Pong pong = new Pong();
	}

	public Pong()
	{
		System.out.println("Starting Pong...");

		initPong();
		initJOGL();

		prevTime = System.nanoTime();
		gameTime = frameTime = 0;
	}

	private void initPong()
	{
		ball = new Ball();
		ball.setPosition(SCREEN_WIDTH/2.0, SCREEN_HEIGHT/2.0);
		ball.setRadius(BALL_RADIUS);
		ball.setColor(0.2f, 1, 0.2f);    

	
		player = new Paddle();
		player.setPosition(10.0, SCREEN_HEIGHT/2.0);
		player.setWidth(10);
		player.setHeight(70);
		player.setColor(1, 0.2f, 0.2f);  
		player.setSpeed(PADDLE_SPEED);
		player.setBounds(player.getHeight()/2, SCREEN_HEIGHT - player.getHeight()/2);

	
		computer = new Paddle();
		computer.setPosition(SCREEN_WIDTH-10.0, SCREEN_HEIGHT/2.0);
		computer.setWidth(10);
		computer.setHeight(70);
		computer.setColor(0.2f, 0.2f, 1);    
		computer.setSpeed(PADDLE_SPEED);
		computer.setBounds(player.getHeight()/2, SCREEN_HEIGHT - computer.getHeight()/2);
	}


	private void initJOGL()
	{
		GLCapabilities caps = new GLCapabilities(GLProfile.getDefault());
		caps.setDoubleBuffered(true);
		caps.setHardwareAccelerated(true);

		frame = new Frame("Pong");
		canvas = new GLCanvas(caps);
		animator = new FPSAnimator(canvas, FPS);

		frame.add(canvas);
		frame.setSize(SCREEN_WIDTH, SCREEN_HEIGHT);
		frame.setLocation(100, 100);
		frame.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				exit();
			}
		});
		frame.setVisible(true);

		canvas.addGLEventListener(this);
		canvas.requestFocus();

		textRenderer = new TextRenderer(new Font("Dialog", Font.BOLD, 60));

		animator.start();

		System.out.println("Initialized JOGL.");
	}

	public static void exit()
	{
		animator.stop();
		frame.dispose();

		System.out.println("Pong is terminated.");
		System.exit(0);
	}

	private double getFrameTime()
	{
		long currTime = System.nanoTime();
		double deltaTime = (currTime - prevTime) / 1000000000.0; 
		prevTime = currTime;
		return deltaTime;
	}

	private void setGameState(GameState state)
	{
		gameState = state;
		if(state == GameState.START){
			playerScore = computerScore = 0;
			AI_UPDATE_TIME = 1.0;    
			BALL_SPEED = 300;    
			ball.setPosition(SCREEN_WIDTH/2, SCREEN_HEIGHT/2);
			ball.setVelocity(0, 0);
			setGameState(GameState.READY);
		}else if(state == GameState.READY){
			readyTime = 0;  
		}else if(state == GameState.GAME){
			ball.fire(SCREEN_WIDTH/2, SCREEN_HEIGHT/2, BALL_SPEED);
		}
	}

	
	private void update()
	{
		if(gameState == GameState.MENU) return;
		else if(gameState == GameState.READY){
			readyTime += frameTime;
			if(readyTime > READY_TIME)
				setGameState(GameState.GAME);
			return;
		}

		ball.update(frameTime);        
		player.update(frameTime);      
		computer.update(frameTime);    
		updateAI();                    

		int hit = hitTest();
		if(hit == 1) sound.play("blip01.wav");
		else if(hit == 2) sound.play("blip02.wav");
		else if(hit == 3){
			sound.play("blip03.wav");
			if(playerScore >= MAX_SCORE || computerScore >= MAX_SCORE){
				setGameState(GameState.MENU);
			}else{
				AI_UPDATE_TIME *= 0.5;     
				BALL_SPEED += 20;			
				setGameState(GameState.READY);
			}
		}
	}

	private void updateAI()
	{
		aiTime += frameTime;
		if(aiTime < AI_UPDATE_TIME) return;
		if(ball.getVelocity().x < 0) return; 

		computer.setMovingDown(false);
		computer.setMovingUp(false);
		aiTime = 0;

		double ballY = ball.getPosition().y;
		double paddleY = computer.getPosition().y;
		double offset = computer.getHeight() / 2.0;

		if(ballY > (paddleY + offset))
			computer.setMovingUp(true);
		else if(ballY < (paddleY - offset))
			computer.setMovingDown(true);
	}

	private int hitTest()
	{
		int hit = 0;
		Vector2 pos = ball.getPosition();
		Vector2 vel = ball.getVelocity();
		double rad = ball.getRadius();

		if(pos.y < 0) 
		{
			ball.setPosition(pos.x, 0);
			ball.setVelocity(vel.x, -vel.y);
			hit = 1;
		}
		else if(pos.y > SCREEN_HEIGHT) 
		{
			ball.setPosition(pos.x, SCREEN_HEIGHT);
			ball.setVelocity(vel.x, -vel.y);
			hit = 1;
		}

		Vector2 left = player.getPosition();    
		Vector2 right = computer.getPosition(); 
		double offset = player.getHeight() / 2.0;

		if(pos.x + rad < 0)
		{
			computerScore++;
			hit = 3;
		}
		else if(pos.x < left.x)
		{
			if(pos.y > (left.y - offset) && pos.y < (left.y + offset))
			{
				ball.setPosition(left.x, pos.y);
				vel = english(vel);
				ball.setVelocity(-vel.x, vel.y);
				hit = 2;
			}
		}

		else if(pos.x - rad > SCREEN_WIDTH)
		{
			playerScore++;
			hit = 3;
		}
		else if(pos.x > right.x)
		{
			if(pos.y > (right.y-offset) && pos.y < (right.y+offset))
			{
				ball.setPosition(right.x, pos.y);
				vel = english(vel);
				ball.setVelocity(-vel.x, vel.y);
				hit = 2;
			}
		}

		return hit;
	}

	private void drawFrame(GLAutoDrawable drawable)
	{
		final GL2 gl = drawable.getGL().getGL2();

		gl.glClear(GL.GL_COLOR_BUFFER_BIT | GL.GL_DEPTH_BUFFER_BIT);

		gl.glLoadIdentity();

		drawBackground(gl);
		drawPaddles(gl, player);    
		drawPaddles(gl, computer);  
		drawBall(gl);

		drawScores();
		drawMessage();

		gl.glFlush();
	}

	private Vector2 english(Vector2 vec)
	{
		Vector2 newVec = new Vector2(vec);
		double length = vec.getLength();

		if(vec.x < 0) {
			if(player.isMovingUp()) {
				newVec.normalize();
				if(vec.y > 0)      newVec.y *= 2.0;
				else if(vec.y < 0) newVec.y *= 0.5;
				newVec.scale(length);
			}
			else if(player.isMovingDown()) {
				newVec.normalize();
				if(vec.y > 0)      newVec.y *= 0.5;
				else if(vec.y < 0) newVec.y *= 2.0;
				newVec.scale(length);
			}
		}else {
			if(computer.isMovingUp()) {
				newVec.normalize();
				if(vec.y > 0)      newVec.y *= 2.0;
				else if(vec.y < 0) newVec.y *= 0.5;
				newVec.scale(length);
			}
			else if(computer.isMovingDown()) {
				newVec.normalize();
				if(vec.y > 0)      newVec.y *= 0.5;
				else if(vec.y < 0) newVec.y *= 2.0;
				newVec.scale(length);
			}
		}
		return newVec;
	}

	private void drawBall(GL2 gl)
	{
		Vector2 center = ball.getPosition();
		double radius = ball.getRadius();
		Color color = ball.getColor();

		gl.glColor3f(color.red, color.green, color.blue);
		gl.glBegin(GL.GL_TRIANGLE_FAN);
		gl.glVertex2d(center.x, center.y);
		for(int angle = 0; angle < 360; angle++){
			gl.glVertex2d(center.x + Math.sin(angle) * radius, center.y + Math.cos(angle) * radius);
		}
		gl.glEnd();
	}

	private void drawPaddles(GL2 gl, Paddle p)
	{
		Vector2 center = p.getPosition();
		double offsetX = p.getWidth() / 2.0;
		double offsetY = p.getHeight() / 2.0;
		Color color = p.getColor();

		gl.glColor3f(color.red, color.green, color.blue);
		gl.glBegin(GL.GL_TRIANGLES);
		gl.glVertex2d(center.x - offsetX, center.y - offsetY);
		gl.glVertex2d(center.x + offsetX, center.y - offsetY);
		gl.glVertex2d(center.x + offsetX, center.y + offsetY);
		gl.glVertex2d(center.x - offsetX, center.y - offsetY);
		gl.glVertex2d(center.x + offsetX, center.y + offsetY);
		gl.glVertex2d(center.x - offsetX, center.y + offsetY);
		gl.glEnd();
	}

	private void drawBackground(GL2 gl)
{
    
    gl.glClear(GL.GL_COLOR_BUFFER_BIT);

    // Criando o gradiente vertical (de cima para baixo)
    float[] topColor = {0.1f, 0.1f, 0.1f}; // Cor do topo (escuro)
    float[] bottomColor = {0.5f, 0.5f, 0.5f}; // Cor de baixo (claro)

    gl.glBegin(GL2.GL_QUADS); 

    // Cor do topo (começo do gradiente)
    gl.glColor3f(topColor[0], topColor[1], topColor[2]);
    gl.glVertex2f(0, SCREEN_HEIGHT);  
    gl.glVertex2f(SCREEN_WIDTH, SCREEN_HEIGHT);  

    // Cor de baixo (final do gradiente)
    gl.glColor3f(bottomColor[0], bottomColor[1], bottomColor[2]);
    gl.glVertex2f(SCREEN_WIDTH, 0);  
    gl.glVertex2f(0, 0);  

    gl.glEnd();

    
    gl.glLineWidth(10);
    gl.glColor3f(1.0f, 1.0f, 1.0f); 

    gl.glBegin(GL.GL_LINES);
    gl.glVertex2f(0, 0);
    gl.glVertex2f(SCREEN_WIDTH, 0);
    gl.glEnd();

    gl.glBegin(GL.GL_LINES);
    gl.glVertex2f(0, SCREEN_HEIGHT);
    gl.glVertex2f(SCREEN_WIDTH, SCREEN_HEIGHT);
    gl.glEnd();

    
    final int DOT_LENGTH = 10;
    gl.glLineWidth(2);
    gl.glBegin(GL.GL_LINES);
    for (int i = 0; i <= SCREEN_HEIGHT; i += DOT_LENGTH * 2)
    {
        gl.glVertex2f(SCREEN_WIDTH / 2, i);
        gl.glVertex2f(SCREEN_WIDTH / 2, i + DOT_LENGTH);
    }
    gl.glEnd();

    gl.glLineWidth(1);
}


	private void drawScores()
	{
		String score;

		textRenderer.beginRendering(SCREEN_WIDTH, SCREEN_HEIGHT);
		textRenderer.setColor(1, 1, 1, 0.5f);   

		score = Integer.toString(playerScore);
		textRenderer.draw(score, 312, 525);

		score = Integer.toString(computerScore);
		textRenderer.draw(score, 466, 525);

		textRenderer.endRendering();
	}

	private void drawMessage()
	{
		if(gameState != GameState.MENU)	return;

		String message = "Aperte espaço para iniciar ";

		Rectangle2D rect = textRenderer.getBounds(message);

		textRenderer.beginRendering(SCREEN_WIDTH, SCREEN_HEIGHT);
		textRenderer.setColor(1, 0, 0, 1.0f);
		textRenderer.draw(message,
				(int)(SCREEN_WIDTH/2.0 - rect.getCenterX()),
				(int)(SCREEN_HEIGHT/2.0 - rect.getCenterY()));

		textRenderer.setColor(0, 0, 1, 1.0f);
		if(playerScore > computerScore)
			textRenderer.draw("Você ganhou :)", 250, 400);
		else if(playerScore < computerScore)
			textRenderer.draw("Você perdeu :(", 250, 400);

		textRenderer.endRendering();
	}

	
	public void init(GLAutoDrawable drawable)
	{
		((Component)drawable).addKeyListener(this);

		GL2 gl = drawable.getGL().getGL2();
		gl.glShadeModel(GLLightingFunc.GL_SMOOTH);
		gl.glClearColor(0.1f, 0.1f, 0.1f, 0.0f); 
		gl.glClearDepth(1.0f);
		gl.glEnable(GL.GL_DEPTH_TEST);
		gl.glDepthFunc(GL.GL_LEQUAL);
		gl.glHint(GL2ES1.GL_PERSPECTIVE_CORRECTION_HINT, GL.GL_NICEST);
	}

	public void reshape(GLAutoDrawable drawable, int x, int y, int w, int h)
	{
		GL2 gl = drawable.getGL().getGL2();

		screenWidth = w;
		screenHeight = h;

		gl.glViewport(0, 0, w, h);

		gl.glMatrixMode(GLMatrixFunc.GL_PROJECTION);
		gl.glLoadIdentity();
		gl.glOrtho(0, SCREEN_WIDTH, 0, SCREEN_HEIGHT, -1, 1);

		gl.glMatrixMode(GLMatrixFunc.GL_MODELVIEW);
		gl.glLoadIdentity();
	}

	public void display(GLAutoDrawable drawable)
	{
		frameTime = getFrameTime();
		gameTime += frameTime;

		update();

		drawFrame(drawable);
	}

	public void dispose(GLAutoDrawable gLDrawable)
	{
	}

	
	public void keyPressed(KeyEvent e)
	{
		switch(e.getKeyCode())
		{
			case KeyEvent.VK_ESCAPE:
				System.out.println("Tecla de escape pressionada. Saindo...");
				exit();
				break;
	
			case KeyEvent.VK_UP:
				player.setMovingUp(true);
				break;
	
			case KeyEvent.VK_DOWN:
				player.setMovingDown(true);
				break;
		}
	}

	public void keyReleased(KeyEvent e)
	{
		switch(e.getKeyCode())
		{
			case KeyEvent.VK_SPACE:
				setGameState(GameState.START);
				break;
	
			case KeyEvent.VK_UP:
				player.setMovingUp(false);
				break;
	
			case KeyEvent.VK_DOWN:
				player.setMovingDown(false);
				break;
		}
	}

	public void keyTyped(KeyEvent e)
	{
	}
}