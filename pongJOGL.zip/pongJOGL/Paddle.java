public class Paddle
{
	private Vector2 position = new Vector2();
	private Color color = new Color();
	private double speed;
	private double width;
	private double height;
	private boolean movingUp;
	private boolean movingDown;
	private double maxY;
	private double minY;

	public Paddle()
	{
	}

	public void setPosition(double x, double y)
	{
		position.set(x, y);
	}

	public void setPosition(Vector2 vec)
	{
		position.set(vec);
	}

	public void setColor(float r, float g, float b)
	{
		color.set(r, g, b);
	}

	public void setColor(Color c)
	{
		color.set(c);
	}

	public void setSpeed(double speed)
	{
		this.speed = speed;
	}

	public void setWidth(double width)
	{
		this.width = width;
	}

	public void setHeight(double height)
	{
		this.height = height;
	}

	public Vector2 getPosition()
	{
		return position.get();
	}

	public Color getColor()
	{
		return color.get();
	}

	public double getSpeed()
	{
		return speed;
	}

	public double getWidth()
	{
		return width;
	}

	public double getHeight()
	{
		return height;
	}

	public String toString()
	{
		return "Paddle(position=" + position + ",\n" +
		       "       color="    + color    + ",\n" +
		       "       speed="    + speed    + ",\n" +
		       "       width="    + width    + ",\n" +
		       "       height="   + height   + ")";
	}

	public void printSelf()
	{
		System.out.println(this);
	}

	public void setMovingUp(boolean flag)
	{
		movingUp = flag;   
	}

	public void setMovingDown(boolean flag)
	{
		movingDown = flag;
	}

	public boolean isMovingUp()
	{
		return movingUp;
	}

	public boolean isMovingDown()
	{
		return movingDown;
	}

	public void setBounds(double min, double max)
	{
		minY = min;
		maxY = max;
	}

	public void update(double deltaTime)
	{
		if(movingUp)
		{
			position.y += deltaTime * speed;
			if(position.y > maxY)
			{
				position.y = maxY;
				movingUp = false;
			}
		}
		if(movingDown)
		{ 
			position.y -= deltaTime * speed;

			if(position.y < minY)
			{
				position.y = minY;
				movingDown = false;
			}    
		}
	}
}